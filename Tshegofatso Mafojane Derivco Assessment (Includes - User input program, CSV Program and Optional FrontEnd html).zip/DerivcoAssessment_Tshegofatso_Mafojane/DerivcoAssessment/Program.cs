﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DerivcoAssessment
{
    internal class Program
    {
        public static void Main(string[] args)
        {

            var watch = new System.Diagnostics.Stopwatch();

            
            HashSet<String> femalePlayers = new HashSet<string>();
            HashSet<String> malePlayers = new HashSet<string>();
            Dictionary<string, int> outputDic = new Dictionary<string, int>();
            watch.Start();
            
            string path = "playerNames.txt";
            var lines = File.ReadAllLines(path);

            foreach (var line in lines)
            {
                var values = line.Split(',');

                if (values[1] == "f") 
                {
                    if (values[0].All(c => char.IsLetter(c))) 
                    {
                        femalePlayers.Add(values[0]);
                    }
                }
                else if (values[1] == "m")
                {
                    if (values[0].All(c => char.IsLetter(c)))
                    {
                        malePlayers.Add(values[0]);
                    }
                }
            }

            foreach (var fp in femalePlayers)
            {
                foreach (var mc in malePlayers)
                {
                    string input = $"{fp} matches {mc}";

                    string Name = input.Replace(" ", "");

                    Name = Name.Trim().ToLower();

                    
                    var chars = Name.ToCharArray();

                    Dictionary<char, int> charMap = new Dictionary<char, int>();

                    

                    
                    foreach (var ch in chars)
                    {
                        if (charMap.ContainsKey(ch))
                        {
                            charMap[ch] = charMap[ch] + 1;
                        }
                        else
                        {
                            charMap.Add(ch, 1);
                        }
                    }

                    
                    var keys = new HashSet<char>(charMap.Keys); 

                    string number = "";

                    foreach (var ch in keys)
                    {
                        number += charMap[ch].ToString();
                    }

                    do
                    {
                        string leftNum = number.Substring(0, (number.Length / 2));
                        string rightNum = number.Substring((number.Length / 2), number.Length - (number.Length / 2));

                        var leftNumArr = leftNum.ToCharArray();
                        var rightNumArr = rightNum.ToCharArray();

                        Array.Reverse(rightNumArr);

                        int[] LArr = Array.ConvertAll(leftNumArr, c => (int)Char.GetNumericValue(c));
                        int[] RArr = Array.ConvertAll(rightNumArr, c => (int)Char.GetNumericValue(c));

                        List<int> sumArr = new List<int>();

                        for (int i = 0; i < LArr.Length; i++)
                        {
                            int tempInt = (LArr[i]) + (RArr[i]);
                            sumArr.Add(tempInt);
                        }
 
                        if (LArr.Length > RArr.Length)
                        {
                            sumArr.Add(LArr[LArr.Length - 1]);
                        }
                        else if (RArr.Length > LArr.Length)
                        {
                            sumArr.Add(RArr[RArr.Length - 1]);
                        }

                        number = "";

                        foreach (var num in sumArr)
                        {
                            string temp = num.ToString();
                            number += temp;
                        }
                    } while (number.Length > 2);

                    if (Convert.ToInt32(number) > 80)
                    {
                        outputDic.Add($"{input} {number}%, good match", Convert.ToInt32(number));
                    }
                    else
                    {
                        outputDic.Add($"{input} {number}%", Convert.ToInt32(number));
                    }
                }
            }

            outputDic = outputDic.OrderByDescending(x => x.Value).ThenBy(x => x.Key).ToDictionary(x => x.Key, x => x.Value);

            foreach (var value in outputDic)
            {
                Console.WriteLine(value.Key);
            }

            File.WriteAllLines("output.txt", outputDic.Keys);
            watch.Stop();
            Console.WriteLine($"Time Taken To Run Program {watch.ElapsedMilliseconds}ms");
            Console.ReadLine();
        }
    }
}