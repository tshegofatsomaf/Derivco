﻿using System;
using System.Text.RegularExpressions;

namespace GoodMatch
{
    class Program
    {
        public static int firstDigit(int n)
        {
            while (n >= 10)
                n /= 10;

            // return the first digit
            return n;
        }

        public static int lastDigit(int n)
        {
            // return the last digit
            return (n % 10);
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Enter first name 1");
            String firstname1 = Console.ReadLine();

            Console.WriteLine("Enter firstname 2");
            String firstname2 = Console.ReadLine();


            String matches = " matches ";

            String message = firstname1 + matches +firstname2;

            //int v = ComputeDistance(firstname1, firstname2);
            Console.WriteLine(message);

            if(string.IsNullOrEmpty(firstname1) || string.IsNullOrEmpty(firstname2))
            {
                Console.WriteLine("First names can't be empty! Input your First names again");
            }
            else
            {
                Regex r = new Regex("^[a-zA-Z]+$");
                if (r.IsMatch(firstname1) || r.IsMatch(firstname2))
                {
                    message = message.Replace(" ", string.Empty);
                    int count = 0;
                    while (message.Length > 0)
                    {
                        //Console.Write(message[0] + " : ");
                         count = 0;
                        for (int j = 0; j < message.Length; j++)
                        {
                            if (message[0] == message[j])
                            {
                                count++;
                            }
                        }
                        Console.Write(count);
                        
                        message = message.Replace(message[0].ToString(), string.Empty);


                        
                    }
                    Console.ReadKey();
                    Console.Write(Math.Floor(Math.Log10(count) + 1));
                }

                else
                    Console.WriteLine("Nothing to match, Please Enter alphabetic names");

                
            }

            
            


        }

        

    }
}

